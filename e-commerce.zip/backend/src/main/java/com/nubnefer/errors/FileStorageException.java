package com.nubnefer.errors;

public class FileStorageException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileStorageException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FileStorageException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FileStorageException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
