/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    extend: {
      colors: {
        'main-color': '#001F3F',
        'alt-color': '#FFD700',
        'alt-color-opacity': '#ffd7007a'
      },
      spacing: {
        '10px':'10px'
      },
      fontSize:{
        '10px':'10px',
        '15px':'15px'
      },
      width:{
        '700px':'700px'
      }
    },
  },
  plugins: [],
}

