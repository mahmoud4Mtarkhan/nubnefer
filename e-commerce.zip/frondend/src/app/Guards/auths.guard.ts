import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { UserAuthService } from '../Services/user-auth.service';

@Injectable({
  providedIn: 'root'
})
export class authsGuard implements CanActivate {
  private isLoggrd:boolean = false;
  constructor(private authService:UserAuthService, private router:Router) {
    this.authService.isUserLogged.subscribe(next=>{this.isLoggrd = next})
  }
  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
      if(this.isLoggrd){
        return true
      } else {
        this.router.navigate(['/signin']);
        return false
      }
  }
}


