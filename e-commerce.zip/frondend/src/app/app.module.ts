import { CUSTOM_ELEMENTS_SCHEMA,NgModule} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './Components/footer/footer.component';
import { ProductListComponent } from './Components/Prdoucts/product-list/product-list.component';
import { FormsModule } from '@angular/forms';
import { DColorsDirective } from './Directives/dcolors.directive';
import { ProductMasterComponent } from './Components/Prdoucts/product-master/product-master.component';
import { ProductDetailsComponent } from './Components/Prdoucts/product-details/product-details.component';
import { CategoryComponent } from './Components/categories/category/category.component';
import { BrandsComponent } from './Components/Prdoucts/brands/brands.component';
import { SignupComponent } from './Components/sign/signup/signup.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MainPageComponent } from './Components/Layouts/main-page/main-page.component';
import { HomeComponent } from './Components/home/home.component';
import { HeaderComponent } from './Components/header/header.component';
import { AllCategoriesComponent } from './Components/categories/all-categories/all-categories.component';
import { SignINComponent } from './Components/sign/sign-in/sign-in.component';
import { DashBoardComponent } from './Components/dash-board/dash-board.component';
import { NgbPaginationModule, NgbAlertModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TestComponent } from './Components/test/test.component';
import { AsideDashboardComponent } from './Components/dash-board/aside-dashboard/aside-dashboard.component';
import { AddProductComponent } from './Components/dash-board/add-product/add-product.component';
import { CatgoriesDashboardComponent } from './Components/dash-board/catgories-dashboard/catgories-dashboard.component';
import { CartComponent } from './Components/cart/cart.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { register } from 'swiper/element/bundle';
import { ProductComponent } from './Components/Prdoucts/product-card/product.component';
import { SliderProductComponent } from './Components/Prdoucts/slider-product/slider-product.component';
import { NavTopComponent } from './Components/header/navbar-top/nav-top.component';
import { NavLinksComponent } from './Components/header/nav-links/nav-links.component';
import { ContentDashboardComponent } from './Components/dash-board/content-dashboard/content-dashboard.component';
import { OrderListComponent } from './Components/dash-board/order-list/order-list.component';
import { ContactUsComponent } from './Components/contact-us/contact-us.component';
import { UsersListComponent } from './Components/dash-board/users-list/users-list.component';
// register Swiper custom elements
register();
@NgModule({
  declarations: [
    AppComponent,
    DColorsDirective,
    ProductMasterComponent,
    CategoryComponent,
    BrandsComponent,
    SignupComponent,
    MainPageComponent,
    ProductDetailsComponent,
    HomeComponent,
    HeaderComponent,
    ProductListComponent,
    FooterComponent,
    AllCategoriesComponent,
    SignINComponent,
    DashBoardComponent,
    TestComponent,
    AsideDashboardComponent,
    AddProductComponent,
    CatgoriesDashboardComponent,
    CartComponent,
    ProductComponent,
    SliderProductComponent,
    NavTopComponent,
    NavLinksComponent,
    ContentDashboardComponent,
    OrderListComponent,
    ContactUsComponent,
    UsersListComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    FontAwesomeModule,
    NgbPaginationModule,
    NgbAlertModule,
    NgbModule,
    BrowserAnimationsModule,
    
    
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
