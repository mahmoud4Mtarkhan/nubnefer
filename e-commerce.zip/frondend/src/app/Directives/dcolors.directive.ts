import { Directive,ElementRef,Renderer2,HostListener,Input, OnChanges } from '@angular/core';

@Directive({
  selector: '[appDColors]'
})
export class DColorsDirective implements OnChanges{

  @Input('appDColors') color:string = "blue"
  constructor(private ele: ElementRef, private renderer: Renderer2) {
  }
  ngOnChanges():void{
    this.renderer.setStyle(this.ele.nativeElement, 'color', this.color);
  }
  @HostListener('mouseover') onMouseOver(){
    this.renderer.setStyle(this.ele.nativeElement, 'color', this.color);
  }
  @HostListener('mouseout') nMouseOut(){
   this.renderer.setStyle(this.ele.nativeElement,'color','#000')
  }
}
