import { DColorsDirective } from './dcolors.directive';

describe('DColorsDirective', () => {
  it('should create an instance', () => {
    const directive = new DColorsDirective();
    expect(directive).toBeTruthy();
  });
});
