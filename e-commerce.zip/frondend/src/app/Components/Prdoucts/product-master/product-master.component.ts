import { Component, ViewChild } from '@angular/core';
import { ICategories } from 'src/app/Models/icategories';
import { StaticCatgoriesService } from 'src/app/Services/static-catgories/static-catgories.service';

@Component({
  selector: 'order-master',
  templateUrl: './product-master.component.html',
  styleUrls: ['./product-master.component.scss']
})
export class ProductMasterComponent {
  categories:ICategories[];
  changePrice:number = 0;
  selectedcat:string = "all";
  constructor(private staticCatgories:StaticCatgoriesService){
    this.categories = staticCatgories.categories;
  }
  PriceFun(event:number){
    this.changePrice = event * 2;
  }
}
