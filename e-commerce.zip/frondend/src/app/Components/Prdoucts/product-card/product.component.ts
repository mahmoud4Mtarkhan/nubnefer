import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { IProduct } from 'src/app/Models/iproduct';
import { faPlus, faMinus } from '@fortawesome/free-solid-svg-icons';
import { StaticProductsService } from 'src/app/Services/static-products/static-products.service';
import { Router } from '@angular/router';
import { CartListService } from 'src/app/Services/cart-list/cart-list.service';
import { UserAuthService } from 'src/app/Services/user-auth.service';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnChanges {
  faMinus = faMinus
  faPlus = faPlus
  @Input('product') receveProduct: IProduct = {} as IProduct
  product: IProduct
  prtList:IProduct[];
  islogged:boolean = false;
  constructor(private staticProducts:StaticProductsService, private router:Router,private cartList:CartListService, private userAuth: UserAuthService ){
      // this.productList = staticProducts.getAllProducts;
      this.product = {} as IProduct
      this.prtList = staticProducts.getAllProducts;
  }
  ngOnChanges(): void {
    this.product = this.receveProduct;
    this.userAuth.isUserLogged.subscribe(next=>{
      this.islogged = next
    })
  }
  prtTrach(index: number, prd: IProduct): number {
    return prd.id
  }
  goToRouter(id: number) {
    this.router.navigate(['/products', id]);
  }
  increment(quantityInput: HTMLInputElement, stockProduct: number) {
    const currentQuantity = +quantityInput.value;
    if (currentQuantity < stockProduct) {
      quantityInput.value = String(currentQuantity + 1)
    }

  }
  decrement(quantityInput: HTMLInputElement) {
    const currentQuantity = +quantityInput.value;
    if (currentQuantity > 0) {
      quantityInput.value = String(currentQuantity - 1)
    }
  }
  addToCart(product: IProduct, quantity: number) {
    let productWithQuantity = product;
    productWithQuantity.quantity = quantity
    let index = this.prtList.findIndex(prd => product.id == prd.id)
    this.prtList[index].stock -= quantity
    this.cartList.addToCart(productWithQuantity)
  }
}
