import { Component, ElementRef, ViewChild } from '@angular/core';
import { IProduct } from 'src/app/Models/iproduct';
import { faPlus,faMinus } from '@fortawesome/free-solid-svg-icons';
import { StaticProductsService } from 'src/app/Services/static-products/static-products.service';

@Component({
  selector: 'slider-product',
  templateUrl: './slider-product.component.html',
  styleUrls: ['./slider-product.component.scss']
})
export class SliderProductComponent {
  @ViewChild('swipers', { static: false }) swipers!: ElementRef;
  swiperParams = {
   slidesPerView: 4,
   spaceBetween: 15,
   breakpoints: {
     0:{
       slidesPerView: 1,
     },
     640: {
       slidesPerView: 2,
       spaceBetween: 10,
     },
     800: {
       slidesPerView: 3,
       spaceBetween: 15,
     },
     1500: {
      slidesPerView: 4,
      spaceBetween: 15,
    },
     1900:{
       slidesPreView: 5,
       spaceBetween: 20,
     }
   },
   on: {
     init() {
       // ...
     },
   },
 };
 faMinus = faMinus
 faPlus = faPlus
 products:IProduct[]
 constructor(private staticProduct:StaticProductsService){
  this.products = staticProduct.getAllProducts.slice(0,10)
 }
 ngAfterViewInit(): void {
  if (this.swipers.nativeElement) {
    Object.assign(this.swipers.nativeElement,this.swiperParams)
    this.swipers.nativeElement.initialize();
  }
}
}
