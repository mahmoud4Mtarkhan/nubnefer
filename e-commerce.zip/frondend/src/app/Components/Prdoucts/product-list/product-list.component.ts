import { Component,Input, OnChanges, Output,EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from 'src/app/Models/iproduct';
import { StaticProductsService } from 'src/app/Services/static-products/static-products.service';
import { faPlus,faMinus } from '@fortawesome/free-solid-svg-icons';
import { CartListService } from 'src/app/Services/cart-list/cart-list.service';
import { UserAuthService } from 'src/app/Services/user-auth.service';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnChanges{
  
  faMinus = faMinus
  faPlus = faPlus
  prtList:IProduct[];
  // productList:IProduct[];
  islogged:boolean = false;
  @Input() sendselectedcat:string = "all";
  @Output() priceEvent:EventEmitter<number>
  constructor(private staticProducts:StaticProductsService, private router:Router,private cartList:CartListService, private userAuth: UserAuthService ){
    this.priceEvent = new EventEmitter<number>();
      // this.productList = staticProducts.getAllProducts;
      this.prtList = staticProducts.getAllProducts;
  }
  ngOnChanges():void{
    this.changeProducts();
    this.userAuth.isUserLogged.subscribe(next=>{
      this.islogged = next
    })
  }
  prtTrach(index:number, prd:IProduct):number {
    return prd.id
  }
  changeProducts():void{
    this.prtList = this.staticProducts.getProductsByCat(this.sendselectedcat);
  }
  convertTO(price:number){
    this.priceEvent.emit(price)
  }
  goToRouter(id:number){
    this.router.navigate(['/products', id]);
  }
  increment(quantityInput: HTMLInputElement, stockProduct:number){
    const currentQuantity = +quantityInput.value;
    if(currentQuantity<stockProduct){
      quantityInput.value = String(currentQuantity + 1)
    }
    
  }
  decrement(quantityInput: HTMLInputElement){
    const currentQuantity = +quantityInput.value;
    if(currentQuantity>0){
      quantityInput.value = String(currentQuantity - 1)
    }
  }
  addToCart(product:IProduct,quantity:number){
    let productWithQuantity = product;
    productWithQuantity.quantity = quantity
    let index = this.prtList.findIndex(prd=>product.id == prd.id)
    this.prtList[index].stock -= quantity
    this.cartList.addToCart(productWithQuantity)
  }
}
