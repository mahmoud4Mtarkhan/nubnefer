import { Location } from '@angular/common';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IProduct } from 'src/app/Models/iproduct';
import { StaticProductsService } from 'src/app/Services/static-products/static-products.service';
import { faPlus,faMinus } from '@fortawesome/free-solid-svg-icons';
import { CartListService } from 'src/app/Services/cart-list/cart-list.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {
  faMinus = faMinus
  faPlus = faPlus;
  product!:IProduct;
  allProducts:IProduct[];
  productListID:number[] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
  currentId!:number;
  constructor(private staticProducts:StaticProductsService, private activatedRoute:ActivatedRoute,private location:Location, private router:Router, private cartService:CartListService){
    this.allProducts = staticProducts.getAllProducts;

  }
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(next=>{
      this.currentId = Number(next.get('pid'));
      this.product = this.staticProducts.getProductByID(this.currentId)
    })


  }
  getPrdIds():number[]{
    return this.productListID

  }
  goBack(){
    this.location.back();
  }
  nextProduct(){
    let currentIndex = this.productListID.findIndex(elem=> elem==this.currentId)
    let nextId
    if (currentIndex < this.productListID.length){
      nextId = this.productListID[currentIndex]+1;
      this.router.navigate(['/products',nextId])

    }
  }
  prevProduct(){
    let currentIndex = this.productListID.findIndex(elem=> elem==this.currentId)
    let prevId
    if (currentIndex > 0){
      prevId = this.productListID[currentIndex]-1;
      this.router.navigate(['/products',prevId])

    }
  }
  imgActive(event:Event) {
    const target = event.target as HTMLElement;
    const allImgs = document.querySelectorAll('.imgG img');
    allImgs.forEach(img => {
      if (img !== target) {
        img.classList.remove('active');
      }
    });
      target.classList.add('active');
  }
  increment(quantityInput: HTMLInputElement, stockProduct:number){
    const currentQuantity = +quantityInput.value;
    if(currentQuantity<stockProduct){
      quantityInput.value = String(currentQuantity + 1)
    }    
  }
  decrement(quantityInput: HTMLInputElement){
    const currentQuantity = +quantityInput.value;
    if(currentQuantity>0){
      quantityInput.value = String(currentQuantity - 1)
    }  
  }
  addToCart(product:IProduct,quantity:number){
    let productWithQuantity = product;
    productWithQuantity.quantity = quantity
    this.cartService.addToCart(productWithQuantity)
  }
}
