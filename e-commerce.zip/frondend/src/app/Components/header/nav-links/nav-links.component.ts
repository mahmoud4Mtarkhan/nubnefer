import { Component,OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/Services/user-auth.service';
import { faCog,faShoppingCart,faSignOut } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'nav-links',
  templateUrl: './nav-links.component.html',
  styleUrls: ['./nav-links.component.scss']
})
export class NavLinksComponent {
  faSetting = faCog;
  faLogOut = faSignOut;
  userName:string = "unkown";
  isLogged:boolean= false;
  dropDownLogIn:boolean= true;
  isPropagationStopped = false;
  isActiveUser:boolean = false;
  navbarToggler:boolean = false;
  faShoppingCart=faShoppingCart
  constructor( private userAuth: UserAuthService){
  }
  ngOnInit():void{
    this.userAuth.isUserLogged.subscribe(next=>{
      this.isLogged = next;
      this.userName = String(localStorage.getItem("username"))
    })
  }
  logIn(user:string,password:string){
    this.userAuth.login(user,password)
    if(this.isLogged){
      this.dropDownLogIn = true
    }
  }
  logOut(){
    this.userAuth.logOut()
  }
  toggleDropLogIn():void{
    this.dropDownLogIn =!this.dropDownLogIn;
  }
}
