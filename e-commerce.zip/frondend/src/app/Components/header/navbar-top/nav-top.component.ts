import { Component, OnInit } from '@angular/core';
import { ICategories } from 'src/app/Models/icategories';
import { StaticCatgoriesService } from 'src/app/Services/static-catgories/static-catgories.service';
import { UserAuthService } from 'src/app/Services/user-auth.service';

@Component({
  selector: 'nav-top',
  templateUrl: './nav-top.component.html',
  styleUrls: ['./nav-top.component.scss']
})
export class NavTopComponent implements OnInit{
  isActive:boolean = false;
  selectedCat:string = "All Categories"
  allCat:ICategories[];
  islogged:boolean = false;
  constructor(private staticCatService:StaticCatgoriesService,private authUser:UserAuthService){
    this.allCat = this.staticCatService.categories;
  }
  ngOnInit(): void {
    this.authUser.isUserLogged.subscribe(next=>{
      this.islogged = next
    })
  }

}
