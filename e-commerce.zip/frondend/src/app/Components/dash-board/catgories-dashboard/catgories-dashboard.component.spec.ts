import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CatgoriesDashboardComponent } from './catgories-dashboard.component';

describe('CatgoriesDashboardComponent', () => {
  let component: CatgoriesDashboardComponent;
  let fixture: ComponentFixture<CatgoriesDashboardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CatgoriesDashboardComponent]
    });
    fixture = TestBed.createComponent(CatgoriesDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
