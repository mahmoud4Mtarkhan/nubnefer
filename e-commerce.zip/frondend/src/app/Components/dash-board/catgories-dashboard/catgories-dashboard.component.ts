import { Component } from '@angular/core';
import {faPlusCircle,faTrashAlt,faSync } from '@fortawesome/free-solid-svg-icons';
import { ICategories } from 'src/app/Models/icategories';
import { StaticCatgoriesService } from 'src/app/Services/static-catgories/static-catgories.service';

@Component({
  selector: 'app-catgories-dashboard',
  templateUrl: './catgories-dashboard.component.html',
  styleUrls: ['./catgories-dashboard.component.scss']
})
export class CatgoriesDashboardComponent {
  faAdd = faPlusCircle;
  faDelete = faTrashAlt;
  faUpdate = faSync;
  categories:ICategories[]
  constructor(private catgoriesService: StaticCatgoriesService){
    this.categories = catgoriesService.categories
  }
  addCateogry(name:string){
    if(name !=''){
      this.catgoriesService.addCateogry(name)
    }
  }
  deleteCateogry(id:number):void{
   this.catgoriesService.deleteCateogry(id)
  }
  updateCateogry(id:number, name:string):void{
    this.catgoriesService.updateCateogry(id,name)
  }
}
