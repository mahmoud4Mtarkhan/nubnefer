import { Component } from '@angular/core';

@Component({
  selector: 'aside-dashboard',
  templateUrl: './aside-dashboard.component.html',
  styleUrls: ['./aside-dashboard.component.scss']
})
export class AsideDashboardComponent {
  isActive:boolean = false;
}
