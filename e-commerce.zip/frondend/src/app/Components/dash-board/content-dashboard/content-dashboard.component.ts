import { Component } from '@angular/core';

@Component({
  selector: 'content-dashboard',
  templateUrl: './content-dashboard.component.html',
  styleUrls: ['./content-dashboard.component.scss']
})
export class ContentDashboardComponent {

}
