import { Component } from '@angular/core';
import {faCaretDown,faTrashAlt,faEdit } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent {
  changeStauts:boolean = false
  faCaretDown = faCaretDown;
  faDelete = faTrashAlt;
  faEdit = faEdit;
}
