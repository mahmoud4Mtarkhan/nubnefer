import { Component, Input, OnChanges  } from '@angular/core';

@Component({
  selector: 'category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnChanges{
  
  @Input('title') receiveTitle:string = "Popular Categories"
  title:string = this.receiveTitle
  ngOnChanges(): void {
    this.title = this.receiveTitle
  }
}
