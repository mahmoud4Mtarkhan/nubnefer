import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/Models/iproduct';
import { CartListService } from 'src/app/Services/cart-list/cart-list.service';
import { UserAuthService } from 'src/app/Services/user-auth.service';
import { faPlus,faMinus } from '@fortawesome/free-solid-svg-icons';
import { StaticProductsService } from 'src/app/Services/static-products/static-products.service';
import {faTrashAlt } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit{
  faMinus = faMinus
  faPlus = faPlus
  faDelete = faTrashAlt
  productsAtCart:IProduct[] = [];
  user:string;
  totalPrice:number = 0;
  constructor(private cartList: CartListService, private userAuth:UserAuthService, private staticProducts: StaticProductsService){
    this.user = userAuth.userName
    this.totalPrice = this.cartList.TotalPrice
  }
  ngOnInit(): void {
    this.cartList.getProductAtList().subscribe(next=>{
      this.productsAtCart = next;
    })
    this.userAuth.isUserLogged.subscribe(next=>{
      this.user = this.userAuth.userName;
      
    })
  }
  deleteById(id:number){
    this.cartList.deleteById(id);
    this.totalPrice = this.cartList.TotalPrice
  }

  // increment(quantityInput: HTMLInputElement, stockProduct:number){
  //   const currentQuantity = +quantityInput.value;
  //   if(currentQuantity<stockProduct){
  //     quantityInput.value = String(currentQuantity + 1)
  //   }
    
  // }
  // decrement(quantityInput: HTMLInputElement,id:number){
  //   const currentQuantity = +quantityInput.value;
  //   let index = this.productsAtCart.findIndex(product=> {return product.id == id})
  //   if(currentQuantity>0){
  //     quantityInput.value = String(currentQuantity - 1)
  //   }
  //   this.productsAtCart[index].quantity = currentQuantity;
  // }
}
