import { TestBed } from '@angular/core/testing';

import { StaticCatgoriesService } from './static-catgories.service';

describe('StaticCatgoriesService', () => {
  let service: StaticCatgoriesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StaticCatgoriesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
