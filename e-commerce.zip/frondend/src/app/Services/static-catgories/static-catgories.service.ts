import { Injectable } from '@angular/core';
import { ICategories } from '../../Models/icategories';

@Injectable({
  providedIn: 'root'
})
export class StaticCatgoriesService {
  categories:ICategories[];
  constructor() {
    this.categories = [
      {id: 1, name:"smartphones"},
      {id: 2, name: "laptops"},
      {id: 3, name: "fragrances"},
      {id: 4, name: "skincare"},
      {id: 5, name: "groceries"},
      {id: 6, name: "home-decoration"},
    ]
   }
   addCateogry(name:string){
    if(this.categories.length == 0){
      this.categories.push({id:1, name:name})
    }else{
      let newId = this.categories[this.categories.length-1].id
      this.categories.push({id:newId+1, name:name})
    }
    
   }
   deleteCateogry(id:number):void{
    let index = this.categories.findIndex(cat => cat.id == id);
    this.categories.splice(index,1)
   }
   updateCateogry(id:number, name:string):void{
    let index = this.categories.findIndex(cat => cat.id == id);
    this.categories[index].name = name;
   }
}
// {id: 1, name:"smartphones"},
//       {id: 2, name: "laptops"},
//       {id: 3, name: "fragrances"},
//       {id: 4, name: "skincare"},
//       {id: 5, name: "groceries"},
//       {id: 6, name: "home-decoration"},