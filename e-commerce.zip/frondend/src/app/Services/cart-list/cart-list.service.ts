import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, from } from 'rxjs';
import { IProduct } from 'src/app/Models/iproduct';

@Injectable({
  providedIn: 'root'
})
export class CartListService {
  productsList:IProduct[] = [
    {
      "id": 1,
      "title": "iPhone 9",
      "description": "An apple mobile which is nothing like apple",
      "price": 549,
      "stock": 94,
      "brand": "Apple",
      "category": "smartphones",
      "thumbnail": "https://i.dummyjson.com/data/products/1/thumbnail.jpg",
      "quantity":10,
      "images": [
      "https://i.dummyjson.com/data/products/1/1.jpg",
      "https://i.dummyjson.com/data/products/1/2.jpg",
      "https://i.dummyjson.com/data/products/1/3.jpg",
      "https://i.dummyjson.com/data/products/1/4.jpg",
      "https://i.dummyjson.com/data/products/1/thumbnail.jpg"
      ]
      },
      {
        "id": 1,
        "title": "iPhone 9",
        "description": "An apple mobile which is nothing like apple",
        "price": 549,
        "stock": 94,
        "brand": "Apple",
        "category": "smartphones",
        "thumbnail": "https://i.dummyjson.com/data/products/1/thumbnail.jpg",
        "quantity":10,
        "images": [
        "https://i.dummyjson.com/data/products/1/1.jpg",
        "https://i.dummyjson.com/data/products/1/2.jpg",
        "https://i.dummyjson.com/data/products/1/3.jpg",
        "https://i.dummyjson.com/data/products/1/4.jpg",
        "https://i.dummyjson.com/data/products/1/thumbnail.jpg"
        ]
        }
  ]
  productsListSubject:BehaviorSubject<IProduct[]>;
  
  constructor() { 
    this.productsListSubject = new BehaviorSubject<IProduct[]>(this.productsList);
  }
  addToCart(product:IProduct){
    const index = this.productsList.findIndex(p => p.id === product.id);
    if (index !== -1) {
      this.productsList[index].quantity =  Number(product.quantity) + Number(this.productsList[index].quantity);
    } else {
      this.productsList.push(product);
    }

    this.productsListSubject.next(this.productsList);

    
  }
  deleteById(id:number){
    let index = this.productsList.findIndex(product=>{return product.id == id})

    this.productsList.splice(index,1)
  }
  get TotalPrice():number{
    return this.productsList.reduce((total,product) =>{return total += (product.price)*(Number(product.quantity))}, 0)
  }
  getProductAtList():Observable<IProduct[]>{
    return this.productsListSubject.asObservable()
  }
}
