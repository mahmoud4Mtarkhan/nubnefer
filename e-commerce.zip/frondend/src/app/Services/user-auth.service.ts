import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  private isLoggedSubject:BehaviorSubject<boolean> ;
  username:string = '';
  constructor() {
    this.isLoggedSubject = new BehaviorSubject(false);
  }
  login(name:string, password:string){
    //call login api, and get Access token
    let userToken = 'statick token'
    localStorage.setItem('token', userToken)
    localStorage.setItem('username',name)
    this.username = String(localStorage.getItem('username'))
    if(name = 'admin', password == '2211'){
      localStorage.setItem('username',name),
      localStorage.setItem('password',password)
      this.isLoggedSubject.next(true);
      console.log(localStorage.getItem('token'))
    }
  }
  
  logOut(){
    localStorage.removeItem('token')
    localStorage.removeItem('username'),
    localStorage.removeItem('password')
    this.isLoggedSubject.next(false)
  }

  get isUserLogged():Observable<boolean>{
    return this.isLoggedSubject.asObservable()
  }
  get userName():string{
    return this.username
  }
}
