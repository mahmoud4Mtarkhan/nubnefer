import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductMasterComponent } from './Components/Prdoucts/product-master/product-master.component';
import { HomeComponent } from './Components/home/home.component';
import { ProductDetailsComponent } from './Components/Prdoucts/product-details/product-details.component';
import { SignupComponent } from './Components/sign/signup/signup.component';
import { MainPageComponent } from './Components/Layouts/main-page/main-page.component';
import { AllCategoriesComponent } from './Components/categories/all-categories/all-categories.component';
import { SignINComponent } from './Components/sign/sign-in/sign-in.component';
import { DashBoardComponent } from './Components/dash-board/dash-board.component';
import { authsGuard } from './Guards/auths.guard';
import { AddProductComponent } from './Components/dash-board/add-product/add-product.component';
import { CatgoriesDashboardComponent } from './Components/dash-board/catgories-dashboard/catgories-dashboard.component';
import { CartComponent } from './Components/cart/cart.component';
import { TestComponent } from './Components/test/test.component';
import { OrderListComponent } from './Components/dash-board/order-list/order-list.component';
import { ContactUsComponent } from './Components/contact-us/contact-us.component';
import { UsersListComponent } from './Components/dash-board/users-list/users-list.component';
const routes: Routes = [
  {path:'', component: MainPageComponent, children: [
    {path:'',redirectTo:'/home', pathMatch: 'full'},
    {path:'contactus', component: ContactUsComponent},
    {path:'cart', component: CartComponent},
    {path:'categories', component: AllCategoriesComponent},
    {path:'products', component: ProductMasterComponent},
    {path:'products/:pid', component: ProductDetailsComponent},
    {path:'home', component: HomeComponent},
  ]},
  {path:'dashboard', component: DashBoardComponent, canActivate:[authsGuard], children: [
    {path:'cateogries', component: CatgoriesDashboardComponent},
    {path:'addproduct', component: AddProductComponent},
    {path:'orderlist', component: OrderListComponent},
    {path:'userlist', component: UsersListComponent}
  ] },
  {path:'signin', component: SignINComponent},
  {path:'test', component: TestComponent,children:[
    {path:'test2', component: CatgoriesDashboardComponent},
  ]},
  {path:'signup', component: SignupComponent},
  {path:'**', redirectTo:'/home'}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
