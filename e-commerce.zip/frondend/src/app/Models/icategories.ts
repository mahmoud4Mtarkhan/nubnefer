export interface ICategories {
  id:number,
  name: string,
}
